//#region - Requirements
const { app } = require('@azure/functions');
const Decrypt = require('../security/decryption');
const SubmitHTTPRequest = require('../helpers/httprequest');
//#endregion

//#region - App Startup
app.setup({
    enableHttpStream: true,
});
//#endregion

//#region - Send Text Notification
function SendTextNotification(paths, config, subject, message) {
    let dict = {
        "to": Decrypt(config.key, config.phonenumber) + config.carrierDomain,
        "subject": subject,
        "message": message
    }

    // Submit HTTP Request
    SubmitHTTPRequest(paths.smsflow, 'POST', JSON.stringify(dict, null, 2));
}
//#endregion

//#region - Send Email Notification
function SendEmailNotification(paths, config, subject, message) {
    let dict = {
        "to": Decrypt(config.key, config.username),
        "subject": subject,
        "message": message
    }

    // Submit HTTP Request
    SubmitHTTPRequest(paths.emailflow, 'POST', JSON.stringify(dict, null, 2));
}
//#endregion

//#region - Export
module.exports = {
    SendTextNotification,
    SendEmailNotification
}
//#endregion