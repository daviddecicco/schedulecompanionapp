//#region - Requirements
const { app } = require('@azure/functions');
//#endregion

//#region - App Setup
app.setup({
    enableHttpStream: true,
});
//#endregion

//#region - Submit HTTP Request
async function SubmitHTTPRequest(url, requestType, jsonData, displayMessage = false) {
    try {
        // Initialize request options
        const options = {
            method: requestType,
            headers: {
                'Content-Type': 'application/json'
            },
            body: jsonData
        };

        // Send the HTTP request
        const response = await fetch(url, options);

        // Check the response status
        if (displayMessage) {
            if (response.status === 202) {
                global.day0session += `• Request Sent Successfully - Response Status${response.status}\n`;
            } else {
                const errorText = await response.text();
                global.day0session += `• Error Sending Request: ${response.status} - ${response.statusText}\n${errorText}`;
            }
        }

    } catch (error) {
        if (displayMessage) {
            global.day0session += `• Error: ${error.message}`;
        }
    }
}
//#endregion

//#region - Export
module.exports = SubmitHTTPRequest;
//#endregion