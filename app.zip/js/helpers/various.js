//#region - Requirements
const { app } = require('@azure/functions');
//#endregion

//#region - App Setup
app.setup({
    enableHttpStream: true,
});
//#endregion

//#region - Get Run Time
function GetRuntime() {
    let runTime = performance.now() - startTime;
    let totalSeconds = runTime / 1000;
    let minutes = Math.floor(totalSeconds / 60);
    let seconds = (totalSeconds % 60).toFixed(2); // Keeping 2 decimal places for seconds
    return `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`; // Add leading zero if needed
}
//#endregion

//#region - Export
module.exports = GetRuntime;
//#endregion