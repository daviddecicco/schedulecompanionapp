// Requirements
const { app } = require('@azure/functions');

// App Setup
app.setup({
    enableHttpStream: true,
});

// // Get Correct Start Time
// function GetCorrectStartTime(target, processes, process, shift) {
//     // Initialize Variables
//     let n = 0;
//     let differences = [];
//     let times = processes[process][`Process_Times_Shift_${shift}`].reduce((acc, t) => (acc.push(t), acc), []);

//     // Helper Function - Convert time to minutes
//     function TimeToMinutes(time) {
//         let [hours, minutes] = time.split(':').map(Number);
//         return hours * 60 + minutes;
//     }

//     // Convert target time to minutes
//     let oMinutes = TimeToMinutes(target);

//     // Iterate Through the Times Array
//     for (let t of times) {
//         // Convert Current Time to Minutes
//         let fMinutes = TimeToMinutes(t);

//         // Get the difference in minutes and store in the array
//         differences[n] = Math.abs(oMinutes - fMinutes);

//         // Increment Index
//         n++;
//     }

//     // Find the index of the minimum difference
//     let minDiffIndex = differences.indexOf(Math.min(...differences));

//     // Return the time at the of the minimum difference, or the target if not found
//     return times[minDiffIndex] || target;
// }

// Get Correct Start Time
function GetCorrectStartTime(target, processes, process, shift) {
    // Logging
    day0session += `        • Getting Correct Start Time - target: ${target}, process: ${process}, shift: ${shift}\n`;

    // Initialize Variables
    let differences = [];
    let times = processes[process][`Process_Times_Shift_${shift}`] || [];
    day0session += `        • Times ${times}\n`;

    // Helper Function - Convert time to minutes
    function TimeToMinutes(time) {
        let [hours, minutes] = time.split(':').map(Number);
        return hours * 60 + minutes;
    }

    // Convert target time to minutes
    let oMinutes = TimeToMinutes(target);
    day0session += `        • oMinutes ${oMinutes}\n`;

    // Iterate Through the Times Array
    for (let t of times) {
        let fMinutes = TimeToMinutes(t);
        day0session += `        • oMinutes ${fMinutes}\n`;
        differences.push(Math.abs(oMinutes - fMinutes));
    }

    // Log Differences
    day0session += `        • differences ${differences}\n`;

    // Find the index of the minimum difference
    let minDiffIndex = differences.indexOf(Math.min(...differences));
    day0session += `        • differences ${minDiffIndex}\n`;

    // Return the time at the index of the minimum difference, or the target if not found
    day0session += `        • returning ${minDiffIndex !== -1 ? times[minDiffIndex] : target}\n`;
    return minDiffIndex !== -1 ? times[minDiffIndex] : target;
}

// Export GetIndex Function
module.exports = GetCorrectStartTime;