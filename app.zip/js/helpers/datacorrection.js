// Requirements
const { app } = require('@azure/functions');

// App Setup
app.setup({
    enableHttpStream: true,
});

// Get Correct Start Time
function GetCorrectStartTime(target, processes, process, shift) {
    // Initialize Variables
    let n = 0;
    let differences = [];
    let times = processes[process][`Process_Times_Shift_${shift}`].reduce((acc, t) => (acc.push(t), acc), []);

    // Helper Function - Convert time to minutes
    function TimeToMinutes(time) {
        let [hours, minutes] = time.split(':').map(Number);
        return hours * 60 + minutes;
    }

    // Convert target time to minutes
    let oMinutes = TimeToMinutes(target);

    // Iterate Through the Times Array
    for (let t of times) {
        // Convert Current Time to Minutes
        let fMinutes = TimeToMinutes(t);

        // Get the difference in minutes and store in the array
        differences[n] = Math.abs(oMinutes - fMinutes);

        // Increment Index
        n++;
    }

    // Find the index of the minimum difference
    let minDiffIndex = differences.indexOf(Math.min(...differences));

    // Return the time at the of the minimum difference, or the target if not found
    return times[minDiffIndex] || target;
}

// Export GetIndex Function
module.exports = GetCorrectStartTime;