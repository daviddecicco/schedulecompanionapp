//#region - Requirements
const { app } = require('@azure/functions');
const Day0Data = require('../classes/dataclasses');
const GetCorrectStartTime = require('../helpers/datacorrection');
//#endregion

//#region - App Setup
app.setup({
    enableHttpStream: true,
});
//#endregion

//#region - Variables
// Lets
let n = -1;
let data = [];
let guid, batch, process;

// Constants
const calendar = 'xpath=//p[contains(text(),"D0, D1 & Aph Spike")]';
const calendarNextDate = '[test-id="calendar-next-btn"]';
const calendarGroupedView = '//*[contains(text(), "Grouped")]';
const calendarIndividualView = '//*[contains(text(), "Individual")]';
const calendarDate = '[class*="date-description"]';
const customEventBody = 'xpath=//*[contains(@class, "dhx_calendar_custom_event_body")]';
const customEventMoveBody = 'xpath=//*[contains(@class, "dhx_event_move dhx_calendar_custom_event_move")]';
const customDemandTags = 'bnc-sidebar-section-readonly-tags';
const customDemandTagsDivs = 'div';
const calendarSidebarClose = '[test-id="sidebar-close-button"]';
const customEventDate = '//input[@placeholder="dd-M-yy"]';
//#endregion

//#region - Day 0 Extraction
async function Day0Extraction(page, config, processes) {
    // Calendar
    await page.locator(calendar).click();
    day0session += `• page.locator - ${calendar}\n`;

    // Extract Data for x number of Days
    for (let currentLoop = 0; currentLoop <= config.totalNumberOfLoops; currentLoop++) {
        // Increment Date
        currentLoop > 0 && await page.locator(calendarNextDate).click();

        // Grouped View Extraction
        console.log(`...Extracting Data from Grouped View (${currentLoop + 1} of ${config.totalNumberOfLoops + 1})`);
        day0session += `\n<a name="groupedViewExtraction${currentLoop + 1}" id="groupedViewExtraction${currentLoop + 1}"><b><u>Grouped View Extraction (${currentLoop + 1} of ${config.totalNumberOfLoops + 1}) (#DATA_COUNT#)</b></u></a>\n`;
        await page.locator(calendarGroupedView).click(); // Click Grouped View Button
        day0session += `• page.locator.clicked - ${calendarGroupedView}\n`;
        await page.waitForLoadState('networkidle'); // Await Idle Network
        day0session += `• GroupedViewExtraction\n`;
        await GroupedViewExtraction(page); // Extract Data

        // Individual View Extraction
        console.log(`...Extracting Data from Individual View (${currentLoop + 1} of ${config.totalNumberOfLoops + 1})`);
        day0session += `\n<a name="individualViewExtraction${currentLoop + 1}" id="individualViewExtraction${currentLoop + 1}"><b><u>Individual View Extraction (${currentLoop + 1} of ${config.totalNumberOfLoops + 1}) (#DATA_COUNT#)</b></u></a>\n`;
        await page.locator(calendarIndividualView).click(); // Click Individual View Button
        day0session += `• page.locator.clicked - ${calendarIndividualView}\n`;
        await page.waitForLoadState('networkidle'); // Await Idle Network
        day0session += `• InvdividualViewExtraction\n`;
        await IndividualViewExtraction(page); // Extract Data
    }

    // Refine Data
    console.log('...Refining Data');
    day0session += `\n<a name="refinedData" id="refinedData"><b><u>Refine Data (#REFINED_COUNT#)</b></u></a>\n`;
    let refinedData = RefineData(processes);

    // Convert to Json
    console.log('...Converting Data to Json Format');
    day0session += `\n<a name="jsonConversion" id="jsonConversion"><b><u>Json Conversion (#JSON_COUNT#)</b></u></a>\n`;
    let jsonData = ConvertToJson(refinedData);

    // Return Data
    return jsonData;
}
//#endregion

//#region - Grouped View Extraction
async function GroupedViewExtraction(page) {
    // Logging Data Count
    let logDataCount = 0;

    // Get Elements
    const elements = await page.locator(customEventBody);
    day0session += `• page.locator - ${customEventBody}\n`;
    const elementsCount = await elements.count();
    day0session += `• elements count - ${elementsCount}\n`;

    // Iterate Through Each Element
    for (let i = 0; i < elementsCount; i++) {
        // Wait for Element to be Visible
        if (await elements.nth(i).isVisible()) {
            // Logging
            day0session += `\n<i><u>• Reading Element i: ${i}</u></i>\n`;
            // Get Text Content
            const textContent = await elements.nth(i).evaluate(el => el.textContent);
            day0session += `• elements text content - ${textContent}\n`;
            const textContents = textContent.split("\n");
            day0session += `• split elements text content - ${textContents}\n`;
            const calendarDateTextContent = await page.locator(calendarDate).textContent();
            day0session += `• calendar date text content - ${calendarDateTextContent}\n`;

            // Base Information
            process = textContent.toLowerCase().includes('Aph'.toLowerCase()) ? 'LFG' : textContent.toLowerCase().includes('D0'.toLowerCase()) ? 'D0' : textContent.toLowerCase().includes('D1'.toLowerCase()) ? 'D1' : '';
            day0session += `• process - ${process}\n`;
            batch = textContents[textContents.findIndex(item => item.toLowerCase().includes('Batch ID'.toLowerCase())) + 1].trim();
            day0session += `• batch - ${batch}\n`;
            guid = `${batch}-${(process == 'LFG') ? 0 : process.replace('D', '')}`;
            day0session += `• guid - ${guid}\n`;

            // Filter
            if (process != '') {
                // Facilitate Array Indices
                const index = data.findIndex(item => item.guid == guid);
                day0session += `• index - ${index}\n`;
                if (index == -1) {
                    data.push(new Day0Data());
                    n++;
                    logDataCount++;
                }
                const c = (index == -1) ? n : index;
                day0session += `• c - ${c}\n`;

                // Cache Base Data
                data[c].calendarDate = calendarDateTextContent.match(/\b\d{2}-[A-Za-z]{3}-\d{4}\b/g)[0];
                data[c].guid = guid;
                data[c].process = process;
                data[c].batch = batch;
                
                // Cache D0 | D1 Information
                if (process.toLowerCase() == 'D0'.toLowerCase() || process.toLowerCase() == 'D1'.toLowerCase()) {
                    // Skip Duplicates
                    if (data[c].groupViewRecorded) {
                        day0session += `<i>• Skipped Duplicate -  Index: ${i} Process:${process}</i>\n`;
                        continue;
                    }

                    // Cache Data
                    data[c].groupViewRecorded = true;
                    day0session += `• groupViewRecorded - ${data[c].groupViewRecorded}\n`;
                    data[c].operator = textContents[textContents.findIndex(item => item.toLowerCase().includes('Operator'.toLowerCase())) + 1].trim();
                    day0session += `• operator - ${data[c].operator}\n`;
                    data[c].verifier = textContents[textContents.findIndex(item => item.toLowerCase().includes('Verifier'.toLowerCase())) + 1].trim();
                    day0session += `• verifier - ${data[c].verifier}\n`;
                    data[c].workstation = textContents[textContents.findIndex(item => item.toLowerCase().includes('Workstation'.toLowerCase())) + 1].trim();
                    day0session += `• workstation - ${data[c].workstation}\n`;
                    data[c].pod = data[c].workstation.toLowerCase().includes('E1416'.toLowerCase()) ? 'Pod 4' : data[c].workstation.toLowerCase().includes('E1422'.toLowerCase()) ? 'Pod 5' : 'Unassigned';
                    day0session += `• pod - ${data[c].pod}\n`;
                    data[c].incubation = textContents[textContents.findIndex(item => item.toLowerCase().includes('Incubation [Equipment]'.toLowerCase())) + 1].trim();
                    day0session += `• incubation - ${data[c].incubation}\n`;
                }

                // Cache LFG Information
                if (process.toLowerCase() == 'LFG'.toLowerCase()) {
                    // Skip Duplicates
                    if (data[c].groupViewRecordedForLFG) {
                        day0session += `\n<i><u>• Skipped Duplicate - Index: ${i} Process: ${process}</u></i>\n`;
                        continue;
                    }

                    // Cache Data
                    data[c].groupViewRecordedForLFG = true;
                    day0session += `• groupViewRecordedForLFG - ${data[c].groupViewRecordedForLFG}\n`;
                    data[c].lfgOperator = textContents[textContents.findIndex(item => item.toLowerCase().includes('Operator'.toLowerCase())) + 1].trim();
                    day0session += `• lfgOperator - ${data[c].lfgOperator}\n`;
                    data[c].lfgVerifier = textContents[textContents.findIndex(item => item.toLowerCase().includes('Verifier'.toLowerCase())) + 1].trim();
                    day0session += `• lfgVerifier - ${data[c].lfgVerifier}\n`;
                }
            }
        }
    }

    // Replace #DATA_COUNT#
    day0session = day0session.replace('#DATA_COUNT#', logDataCount);
}
//#endregion

//#region - Individual View Extraction
async function IndividualViewExtraction(page) {
    // Logging Data Count
    let logDataCount = 0;

    // Get Elements
    const dataElements = await page.locator(customEventBody);
    day0session += `• page.locator - ${customEventBody}\n`;
    const clickElements = await page.locator(customEventMoveBody);
    day0session += `• page.locator - ${customEventMoveBody}\n`;
    const clickElementsCount = await clickElements.count();
    day0session += `• click elements count - ${clickElementsCount}\n`;

    // Iterate Through Each Element
    for (let i = 0; i < clickElementsCount; i++) {
        // Wait for Element to be Visible
        if (clickElements.nth(i).isVisible() && clickElements.nth(i).isEnabled()) {
            // Logging
            day0session += `\n<i><u>• Reading Element i: ${i}</u></i>\n`;
            // Get Process Filter
            const textContent = await dataElements.nth(i).evaluate(el => el.textContent);
            day0session += `• elements text content - ${textContent}\n`;
            process = textContent.toLowerCase().includes('Aph'.toLowerCase()) ? 'LFG' : textContent.toLowerCase().includes('D0'.toLowerCase()) ? 'D0' : textContent.toLowerCase().includes('D1'.toLowerCase()) ? 'D1' : '';
            day0session += `• process - ${process}\n`;

            // Filter - Personal Schedule
            if (textContent.toLowerCase().includes('Operator'.toLowerCase()) || textContent.toLowerCase().includes('Verifier'.toLowerCase())) {
                day0session += `\n<i><u>• Skipped Personal Schedule - Index ${i}</u></i>\n`;
                continue;
            }

            // Filter - Process
            if (process.toLowerCase() == 'D0'.toLowerCase() || process.toLowerCase() == 'D1'.toLowerCase()) {
                // Click Element
                await clickElements.nth(i).click();
                day0session += `• Clicked Index ${i}\n`;

                // Get Indexing Information
                batch = textContent.match(/\d{2}[a-zA-Z]{2}\d+[a-zA-Z]*/);
                day0session += `• batch - ${batch}\n`;
                guid = `${batch}-${(process == 'LFG') ? 0 : process.replace('D', '')}`;
                day0session += `• guid - ${guid}\n`;
                
                // Find Matching Index
                if (batch) {
                    // Index
                    const c = data.findIndex(item => item.guid == guid);
                    day0session += `• c - ${c}\n`;

                    // Skip Duplicates
                    if (data[c].individualViewRecorded) {
                        day0session += `\n<i><u>• Skipped Duplicate - Index ${i}</u></i>\n`;
                        continue;
                    }

                    // Logging Data Count
                    logDataCount++;

                    // Prerequisite Information
                    const demandTags = await page.locator(customDemandTags); // Demand Tags
                    day0session += `• page.locator - ${customDemandTags}\n`;
                    const divs = await demandTags.nth(0).locator(customDemandTagsDivs); // Demand Tags Divs
                    day0session += `• demandTags.nth(0).locator - ${customDemandTagsDivs}\n`;
                    const divsCount = await divs.count(); // Demand Tags Divs Count
                    day0session += `• divs count - ${divsCount}\n`;

                    // Mark Recorded
                    data[c].individualViewRecorded = true;
                    day0session += `• individualViewRecorded - ${data[c].individualViewRecorded}\n`;

                    // Date
                    data[c].date = await page.inputValue(customEventDate);
                    day0session += `• date - ${data[c].date}\n`;

                    // Get Remaining Data
                    for (let j = 0; j < divsCount; j++) {
                        // Cache Values
                        const val = await divs.nth(j).textContent();
                        day0session += `• val - ${val}\n`;

                        // PO
                        if (val.toLowerCase() == 'PO'.toLowerCase()) {
                            data[c].po = await divs.nth(j + 1).textContent();
                            day0session += `<i><u>• PO - ${data[c].po}</u></i>\n`;
                        }
                        // Requested Start Time
                        if (val.toLowerCase() == 'Requested Start Time'.toLowerCase()) {
                            data[c].time = await divs.nth(j + 1).textContent();
                            day0session += `<i><u>• Requested Start Time - ${data[c].time}</u></i>\n`;
                        }
                        // Country
                        if (val.toLowerCase() == 'Country'.toLowerCase()) {
                            data[c].country = await divs.nth(j + 1).textContent();
                            day0session += `<i><u>• Country - ${data[c].country}</u></i>\n`;
                        }
                        // Supply Type
                        if (val.toLowerCase() == 'Supply Type'.toLowerCase()) {
                            data[c].supplyType = await divs.nth(j + 1).textContent();
                            day0session += `<i><u>• Supply Type - ${data[c].supplyType}</u></i>\n`;
                        }
                        // Allocated Shift
                        if (val.toLowerCase() == 'Allocated Shift'.toLowerCase()) {
                            data[c].shift = await divs.nth(j + 1).textContent();
                            day0session += `<i><u>• Allocated Shift - ${data[c].shift}</u></i>\n`;
                        }
                        // Slot State
                        if (val.toLowerCase() == 'Slot State'.toLowerCase()) {
                            data[c].slotState = await divs.nth(j + 1).textContent();
                            day0session += `<i><u>• Slot State - ${data[c].slotState}</u></i>\n`;
                        }
                    }
               } else {
                    day0session += `\n<i><u>• Filtered out index ${i}</u></i>\n`;
               }

                // Close Sidebar
                await page.waitForTimeout(500);
                await page.locator(calendarSidebarClose).click();
                day0session += `• page.locator.click - ${calendarSidebarClose}\n`;
                await page.waitForTimeout(500);
            }
       }
    }

    // Replace #DATA_COUNT#
    day0session = day0session.replace('#DATA_COUNT#', logDataCount);
}
//#endregion

//#region - Refine Data
function RefineData(processes) {
    // Variables
    let n = 0;
    let refinedData = [];

    // Iterate Each Data
    for (let i = 0; i < data.length; i++) {
        // Filter Date
        if (data[i].calendarDate == data[i].date && data[i].date != '') {
            // Filter Slot State
            if (data[i].slotState.toLowerCase() == 'Booked'.toLowerCase() || data[i].slotState.toLowerCase() == 'Terminated'.toLowerCase()) {
                // Create Index
                refinedData.push(new Day0Data());
                day0session += `\n<i><u>• Added Index to Refined Data -  i: ${i}</u></i>\n`;

                // Refine Data
                refinedData[n].calendarDate = data[i].calendarDate; //Calendar Date
                day0session += `• calendarDate - ${refinedData[n].calendarDate}\n`;
                refinedData[n].guid = data[i].guid; //GUID
                day0session += `• guid - ${refinedData[n].guid}\n`;
                refinedData[n].date = data[i].date // Date
                day0session += `• date - ${refinedData[n].date}\n`;
                refinedData[n].process = data[i].process; // Process
                day0session += `• process - ${refinedData[n].process}\n`;
                refinedData[n].batch = data[i].batch; // Batch
                day0session += `• batch - ${refinedData[n].batch}\n`;
                refinedData[n].po = data[i].po; // PO
                day0session += `• po - ${refinedData[n].po}\n`;
                refinedData[n].country = data[i].country; // Country
                day0session += `• country - ${refinedData[n].country}\n`;
                refinedData[n].supplyType = data[i].supplyType; // Supply Type
                day0session += `• supplyType - ${refinedData[n].supplyType}\n`;
                refinedData[n].workstation = data[i].workstation; // Workstation
                day0session += `• workstation - ${refinedData[n].workstation}\n`;
                refinedData[n].pod = data[i].pod; // Pod
                day0session += `• pod - ${refinedData[n].pod}\n`;
                refinedData[n].operator = data[i].operator; // Operator
                day0session += `• operator - ${refinedData[n].operator}\n`;
                refinedData[n].verifier = data[i].verifier; // Verifier
                day0session += `• verifier - ${refinedData[n].verifier}\n`;
                refinedData[n].shift = data[i].shift == '1st' ? '1' : '2'; // Shift
                day0session += `• shift - ${refinedData[n].shift}\n`;
                refinedData[n].incubation = data[i].incubation; // Incubation
                day0session += `• incubation - ${refinedData[n].incubation}\n`;
                refinedData[n].lfgOperator = data[i].lfgOperator; // LFG Operator
                day0session += `• lfgOperator - ${refinedData[n].lfgOperator}\n`;
                refinedData[n].lfgVerifier = data[i].lfgVerifier;; // LFG Verifier
                day0session += `• lfgVerifier - ${refinedData[n].lfgVerifier}\n`;
                refinedData[n].slotState = data[i].slotState; // Slot State
                day0session += `• slotState - ${refinedData[n].slotState}\n`;
                refinedData[n].time = GetCorrectStartTime(data[i].time, processes, refinedData[n].process, refinedData[n].shift); // Time
                day0session += `• time - ${refinedData[n].time}\n`;

                // Increment Index
                n++;
            } else {
                day0session += `\n<i><u>• Filtered Index ${i} due to slot state</u></i>\n`;
            }
        } else {
            day0session += `\n<i><u>• Filtered Index ${i} due to Date</u></i>\n`;
        }
    }
    // Replace #REFINED_COUNT#
    day0session = day0session.replace('#REFINED_COUNT#', refinedData.length);

    // Return RefinedData
    return refinedData;
}
//#endregion

//#region - Convert to json
function ConvertToJson(myData) {
    // Initialize Variables
    let collection = [];

    // Iterate Through Data
    for (let i = 0; i < myData.length; i++) {
        // Dictionary
        let dict = {
            "GUID": myData[i].guid,
            "Date": myData[i].date,
            "Process": myData[i].process,
            "Batch": myData[i].batch,
            "Operator": myData[i].operator,
            "Verifier": myData[i].verifier,
            "Workstation": myData[i].workstation,
            "Pod": myData[i].pod,
            "Incubation": myData[i].incubation,
            "StartTime": myData[i].time,
            "Country": myData[i].country,
            "Shift": myData[i].shift,
            "SupplyType": myData[i].supplyType,
            "PO": myData[i].po,
            "LFGOperator": myData[i].lfgOperator,
            "LFGVerifier": myData[i].lfgVerifier,
            "SlotState": myData[i].slotState
        }
        // Add to Collection
        collection.push(dict);
    }

    // Replace #JSON_COUNT#
    day0session = day0session.replace('#JSON_COUNT#', collection.length);

    // Return Json String
    day0session += `• Collection converted to JSON\n${JSON.stringify(collection, null, 2)}\n`;
    return JSON.stringify(collection, null, 2);
}
//#endregion

//#region - Export Functions
module.exports = Day0Extraction;
//#endregion