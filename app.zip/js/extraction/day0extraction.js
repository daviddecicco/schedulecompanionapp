//#region - Requirements
const { app } = require('@azure/functions');
const Day0Data = require('../classes/dataclasses');
const GetCorrectStartTime = require('../helpers/datacorrection');
//#endregion

//#region - App Setup
app.setup({
    enableHttpStream: true,
});
//#endregion

//#region - Variables
// Lets
let n = -1;
let data = [];
let guid, batch, process;

// Constants
const calendar = 'xpath=//p[contains(text(),"D0, D1 & Aph Spike")]';
const calendarNextDate = '[test-id="calendar-next-btn"]';
const calendarGroupedView = '//*[contains(text(), "Grouped")]';
const calendarIndividualView = '//*[contains(text(), "Individual")]';
const calendarDate = '[class*="date-description"]';
const customEventBody = 'xpath=//*[contains(@class, "dhx_calendar_custom_event_body")]';
const customEventMoveBody = 'xpath=//*[contains(@class, "dhx_event_move dhx_calendar_custom_event_move")]';
const customDemandTags = 'bnc-sidebar-section-readonly-tags';
const customDemandTagsDivs = 'div';
const calendarSidebarClose = '[test-id="sidebar-close-button"]';
const customEventDate = '//input[@placeholder="dd-M-yy"]';
//#endregion

//#region - Day 0 Extraction
async function Day0Extraction(page, config, processes) {
    // Calendar
    await page.locator(calendar).click();
    global.day0session += `• page.locator - ${calendar}\n`;

    // Extract Data for x number of Days
    for (let currentLoop = 0; currentLoop <= config.totalNumberOfLoops; currentLoop++) {
        // Increment Date
        currentLoop > 0 && await page.locator(calendarNextDate).click();

        // Grouped View Extraction
        global.day0session += `\n<a name="groupedViewExtraction" id="groupedViewExtraction"><b><u>Grouped View Extraction</b></u></a>\n`;
        await page.locator(calendarGroupedView).click(); // Click Grouped View Button
        global.day0session += `• page.locator.clicked - ${calendarGroupedView}\n`;
        await page.waitForLoadState('networkidle'); // Await Idle Network
        global.day0session += `• GroupedViewExtraction\n`;
        await GroupedViewExtraction(page); // Extract Data

        // Individual View Extraction
        global.day0session += `\n<a name="individualViewExtraction" id="individualViewExtraction"><b><u>Individual View Extraction</b></u></a>\n`;
        await page.locator(calendarIndividualView).click(); // Click Individual View Button
        global.day0session += `• page.locator.clicked - ${calendarIndividualView}\n`;
        await page.waitForLoadState('networkidle'); // Await Idle Network
        global.day0session += `• InvdividualViewExtraction\n`;
        await IndividualViewExtraction(page); // Extract Data
    }

    // Refine Data
    global.day0session += `\n<a name="refinedData" id="refinedData"><b><u>Refine Data</b></u></a>\n`;
    let refinedData = RefineData(processes);

    // Convert to Json
    global.day0session += `\n<a name="jsonConversion" id="jsonConversion"><b><u>Json Conversion</b></u></a>\n`;
    let jsonData = ConvertToJson(refinedData);

    // Return Data
    return jsonData;
}
//#endregion

//#region - Grouped View Extraction
async function GroupedViewExtraction(page) {
    // Get Elements
    const elements = await page.locator(customEventBody);
    global.day0session += `• page.locator - ${customEventBody}\n`;
    const elementsCount = await elements.count();
    global.day0session += `• elements count - ${elementsCount}\n`;

    // Iterate Through Each Element
    for (let i = 0; i < elementsCount; i++) {
        // Wait for Element to be Visible
        if (await elements.nth(i).isVisible()) {
            // Logging
            global.day0session += `\n<i><u>• Reading Element i: ${i}</u></i>\n`;
            // Get Text Content
            const textContent = await elements.nth(i).evaluate(el => el.textContent);
            global.day0session += `• elements text content - ${textContent}\n`;
            const textContents = textContent.split("\n");
            global.day0session += `• split elements text content - ${textContents}\n`;
            const calendarDateTextContent = await page.locator(calendarDate).textContent();
            global.day0session += `• calendar date text content - ${calendarDateTextContent}\n`;

            // Base Information
            process = textContent.toLowerCase().includes('Aph'.toLowerCase()) ? 'LFG' : textContent.toLowerCase().includes('D0'.toLowerCase()) ? 'D0' : textContent.toLowerCase().includes('D1'.toLowerCase()) ? 'D1' : '';
            global.day0session += `• process - ${process}\n`;
            batch = textContents[textContents.findIndex(item => item.toLowerCase().includes('Batch ID'.toLowerCase())) + 1].trim();
            global.day0session += `• batch - ${batch}\n`;
            guid = `${batch}-${(process == 'LFG') ? 0 : process.replace('D', '')}`;
            global.day0session += `• guid - ${guid}\n`;

            // Filter
            if (process != '') {
                // Facilitate Array Indices
                const index = data.findIndex(item => item.guid == guid);
                global.day0session += `• index - ${index}\n`;
                if (index == -1) {
                    data.push(new Day0Data());
                    n++;
                }
                const c = (index == -1) ? n : index;
                global.day0session += `• c - ${c}\n`;

                // Cache Base Data
                data[c].calendarDate = calendarDateTextContent.match(/\b\d{2}-[A-Za-z]{3}-\d{4}\b/g)[0];
                data[c].guid = guid;
                data[c].process = process;
                data[c].batch = batch;
                
                // Cache D0 | D1 Information
                if (process.toLowerCase() == 'D0'.toLowerCase() || process.toLowerCase() == 'D1'.toLowerCase()) {
                    // Skip Duplicates
                    if (data[c].groupViewRecorded) {
                        global.day0session += `<i>• Skipped Duplicate -  Index: ${i} Process:${process}</i>\n`;
                        continue;
                    }

                    // Cache Data
                    data[c].groupViewRecorded = true;
                    global.day0session += `• groupViewRecorded - ${data[c].groupViewRecorded}\n`;
                    data[c].operator = textContents[textContents.findIndex(item => item.toLowerCase().includes('Operator'.toLowerCase())) + 1].trim();
                    global.day0session += `• operator - ${data[c].operator}\n`;
                    data[c].verifier = textContents[textContents.findIndex(item => item.toLowerCase().includes('Verifier'.toLowerCase())) + 1].trim();
                    global.day0session += `• verifier - ${data[c].verifier}\n`;
                    data[c].workstation = textContents[textContents.findIndex(item => item.toLowerCase().includes('Workstation'.toLowerCase())) + 1].trim();
                    global.day0session += `• workstation - ${data[c].workstation}\n`;
                    data[c].pod = data[c].workstation.toLowerCase().includes('E1416'.toLowerCase()) ? 'Pod 4' : data[c].workstation.toLowerCase().includes('E1422'.toLowerCase()) ? 'Pod 5' : 'Unassigned';
                    global.day0session += `• pod - ${data[c].pod}\n`;
                    data[c].incubation = textContents[textContents.findIndex(item => item.toLowerCase().includes('Incubation [Equipment]'.toLowerCase())) + 1].trim();
                    global.day0session += `• incubation - ${data[c].incubation}\n`;
                }

                // Cache LFG Information
                if (process.toLowerCase() == 'LFG'.toLowerCase()) {
                    // Skip Duplicates
                    if (data[c].groupViewRecordedForLFG) {
                        global.day0session += `\n<i><u>• Skipped Duplicate - Index: ${i} Process: ${process}</u></i>\n`;
                        continue;
                    }

                    // Cache Data
                    data[c].groupViewRecordedForLFG = true;
                    global.day0session += `• groupViewRecordedForLFG - ${data[c].groupViewRecordedForLFG}\n`;
                    data[c].lfgOperator = textContents[textContents.findIndex(item => item.toLowerCase().includes('Operator'.toLowerCase())) + 1].trim();
                    global.day0session += `• lfgOperator - ${data[c].lfgOperator}\n`;
                    data[c].lfgVerifier = textContents[textContents.findIndex(item => item.toLowerCase().includes('Verifier'.toLowerCase())) + 1].trim();
                    global.day0session += `• lfgVerifier - ${data[c].lfgVerifier}\n`;
                }
            }
        }
    }
}
//#endregion

//#region - Individual View Extraction
async function IndividualViewExtraction(page) {
    // Get Elements
    const dataElements = await page.locator(customEventBody);
    global.day0session += `• page.locator - ${customEventBody}\n`;
    const clickElements = await page.locator(customEventMoveBody);
    global.day0session += `• page.locator - ${customEventMoveBody}\n`;
    const clickElementsCount = await clickElements.count();
    global.day0session += `• click elements count - ${clickElementsCount}\n`;

    // Iterate Through Each Element
    for (let i = 0; i < clickElementsCount; i++) {
        // Wait for Element to be Visible
        if (clickElements.nth(i).isVisible() && clickElements.nth(i).isEnabled()) {
            // Logging
            global.day0session += `\n<i><u>• Reading Element i: ${i}</u></i>\n`;
            // Get Process Filter
            const textContent = await dataElements.nth(i).evaluate(el => el.textContent);
            global.day0session += `• elements text content - ${textContent}\n`;
            process = textContent.toLowerCase().includes('Aph'.toLowerCase()) ? 'LFG' : textContent.toLowerCase().includes('D0'.toLowerCase()) ? 'D0' : textContent.toLowerCase().includes('D1'.toLowerCase()) ? 'D1' : '';
            global.day0session += `• process - ${process}\n`;

            // Filter - Personal Schedule
            if (textContent.toLowerCase().includes('Operator'.toLowerCase()) || textContent.toLowerCase().includes('Verifier'.toLowerCase())) {
                global.day0session += `\n<i><u>• Skipped Personal Schedule - Index ${i}</u></i>\n`;
                continue;
            }

            // Filter - Process
            if (process.toLowerCase() == 'D0'.toLowerCase() || process.toLowerCase() == 'D1'.toLowerCase()) {
                // Click Element
                await clickElements.nth(i).click();
                global.day0session += `• Clicked Index ${i}\n`;

                // Get Indexing Information
                batch = textContent.match(/\d{2}[a-zA-Z]{2}\d+[a-zA-Z]*/);
                global.day0session += `• batch - ${batch}\n`;
                guid = `${batch}-${(process == 'LFG') ? 0 : process.replace('D', '')}`;
                global.day0session += `• guid - ${guid}\n`;
                
                // Find Matching Index
                if (batch) {
                    // Index
                    const c = data.findIndex(item => item.guid == guid);
                    global.day0session += `• c - ${c}\n`;

                    // Skip Duplicates
                    if (data[c].individualViewRecorded) {
                        global.day0session += `\n<i><u>• Skipped Duplicate - Index ${i}</u></i>\n`;
                        continue;
                    }

                    // Prerequisite Information
                    const demandTags = await page.locator(customDemandTags); // Demand Tags
                    global.day0session += `• page.locator - ${customDemandTags}\n`;
                    const divs = await demandTags.nth(0).locator(customDemandTagsDivs); // Demand Tags Divs
                    global.day0session += `• demandTags.nth(0).locator - ${customDemandTagsDivs}\n`;
                    const divsCount = await divs.count(); // Demand Tags Divs Count
                    global.day0session += `• divs count - ${divsCount}\n`;

                    // Mark Recorded
                    data[c].individualViewRecorded = true;
                    global.day0session += `• individualViewRecorded - ${data[c].individualViewRecorded}\n`;

                    // Date
                    data[c].date = await page.inputValue(customEventDate);
                    global.day0session += `• date - ${data[c].date}\n`;

                    // Get Remaining Data
                    for (let j = 0; j < divsCount; j++) {
                        // Cache Values
                        const val = await divs.nth(j).textContent();
                        global.day0session += `• val - ${val}\n`;

                        // PO
                        if (val.toLowerCase() == 'PO'.toLowerCase()) {
                            data[c].po = await divs.nth(j + 1).textContent();
                            global.day0session += `<i>• PO - ${data[c].po}</i>\n`;
                        }
                        // Requested Start Time
                        if (val.toLowerCase() == 'Requested Start Time'.toLowerCase()) {
                            data[c].time = await divs.nth(j + 1).textContent();
                            global.day0session += `<i>• Requested Start Time - ${data[c].time}</i>\n`;
                        }
                        // Country
                        if (val.toLowerCase() == 'Country'.toLowerCase()) {
                            data[c].country = await divs.nth(j + 1).textContent();
                            global.day0session += `<i>• Country - ${data[c].country}</i>\n`;
                        }
                        // Supply Type
                        if (val.toLowerCase() == 'Supply Type'.toLowerCase()) {
                            data[c].supplyType = await divs.nth(j + 1).textContent();
                            global.day0session += `<i>• Supply Type - ${data[c].supplyType}</i>\n`;
                        }
                        // Allocated Shift
                        if (val.toLowerCase() == 'Allocated Shift'.toLowerCase()) {
                            data[c].shift = await divs.nth(j + 1).textContent();
                            global.day0session += `<i>• Allocated Shift - ${data[c].shift}</i>\n`;
                        }
                        // Slot State
                        if (val.toLowerCase() == 'Slot State'.toLowerCase()) {
                            data[c].slotState = await divs.nth(j + 1).textContent();
                            global.day0session += `<i>• Slot State - ${data[c].slotState}</i>\n`;
                        }
                    }
               } else {
                    global.day0session += `\n<i><u>• Filtered out index ${i}</u></i>\n`;
               }

                // Close Sidebar
                await page.waitForTimeout(500);
                await page.locator(calendarSidebarClose).click();
                global.day0session += `• page.locator.click - ${calendarSidebarClose}\n`;
                await page.waitForTimeout(500);
            }
       }
    }
}
//#endregion

//#region - Refine Data
function RefineData(processes) {
    // Variables
    let n = 0;
    let refinedData = [];

    // Iterate Each Data
    for (let i = 0; i < data.length; i++) {
        // Filter Date
        if (data[i].calendarDate == data[i].date && data[i].date != '') {
            // Filter Slot State
            if (data[i].slotState.toLowerCase() == 'Booked'.toLowerCase() || data[i].slotState.toLowerCase() == 'Terminated'.toLowerCase()) {
                // Create Index
                refinedData.push(new Day0Data());
                global.day0session += `\n<i>• Added Index to Refined Data: i: ${i}</i>\n`;

                // Refine Data
                refinedData[n].calendarDate = data[i].calendarDate; //Calendar Date
                global.day0session += `• calendarDate - ${refinedData[n].calendarDate}\n`;
                refinedData[n].guid = data[i].guid; //GUID
                global.day0session += `• guid - ${refinedData[n].guid}\n`;
                refinedData[n].date = data[i].date // Date
                global.day0session += `• date - ${refinedData[n].date}\n`;
                refinedData[n].process = data[i].process; // Process
                global.day0session += `• process - ${refinedData[n].process}\n`;
                refinedData[n].batch = data[i].batch; // Batch
                global.day0session += `• batch - ${refinedData[n].batch}\n`;
                refinedData[n].po = data[i].po; // PO
                global.day0session += `• po - ${refinedData[n].po}\n`;
                refinedData[n].country = data[i].country; // Country
                global.day0session += `• country - ${refinedData[n].country}\n`;
                refinedData[n].supplyType = data[i].supplyType; // Supply Type
                global.day0session += `• supplyType - ${refinedData[n].supplyType}\n`;
                refinedData[n].workstation = data[i].workstation; // Workstation
                global.day0session += `• workstation - ${refinedData[n].workstation}\n`;
                refinedData[n].pod = data[i].pod; // Pod
                global.day0session += `• pod - ${refinedData[n].pod}\n`;
                refinedData[n].operator = data[i].operator; // Operator
                global.day0session += `operator - ${refinedData[n].operator}\n`;
                refinedData[n].verifier = data[i].verifier; // Verifier
                global.day0session += `• verifier - ${refinedData[n].verifier}\n`;
                refinedData[n].shift = data[i].shift == '1st' ? '1' : '2'; // Shift
                global.day0session += `• shift - ${refinedData[n].shift}\n`;
                refinedData[n].incubation = data[i].incubation; // Incubation
                global.day0session += `• incubation - ${refinedData[n].incubation}\n`;
                refinedData[n].lfgOperator = data[i].lfgOperator; // LFG Operator
                global.day0session += `• lfgOperator - ${refinedData[n].lfgOperator}\n`;
                refinedData[n].lfgVerifier = data[i].lfgVerifier;; // LFG Verifier
                global.day0session += `• lfgVerifier - ${refinedData[n].lfgVerifier}\n`;
                refinedData[n].slotState = data[i].slotState; // Slot State
                global.day0session += `• slotState - ${refinedData[n].slotState}\n`;
                refinedData[n].time = GetCorrectStartTime(data[n].time, processes, refinedData[n].process, refinedData[n].shift); // Time
                global.day0session += `• time - ${refinedData[n].time}\n`;

                // Increment Index
                n++;
            } else {
                global.day0session += `\n<i><u>• Filtered Index ${i} due to slot state</u></i>\n`;
            }
        } else {
            global.day0session += `\n<i><u>• Filtered Index ${i} due to Date</u></i>\n`;
        }
    }

    // Return RefinedData
    return refinedData;
}
//#endregion

//#region - Convert to json
function ConvertToJson(myData) {
    // Initialize Variables
    let collection = [];

    // Iterate Through Data
    for (let i = 0; i < myData.length; i++) {
        // Dictionary
        let dict = {
            "GUID": myData[i].guid,
            "Date": myData[i].date,
            "Process": myData[i].process,
            "Batch": myData[i].batch,
            "Operator": myData[i].operator,
            "Verifier": myData[i].lfgOperator,
            "Workstation": myData[i].workstation,
            "Pod": myData[i].pod,
            "Incubation": myData[i].incubation,
            "StartTime": myData[i].time,
            "Country": myData[i].country,
            "Shift": myData[i].shift,
            "SupplyType": myData[i].supplyType,
            "PO": myData[i].po,
            "LFGOperator": myData[i].lfgOperator,
            "LFGVerifier": myData[i].lfgVerifier,
            "SlotState": myData[i].slotState
        }

        // Add to Collection
        collection.push(dict);
    }

    // Return Json String
    global.day0session += `• Collection converted to JSON\n${JSON.stringify(collection, null, 2)}\n`;
    return JSON.stringify(collection, null, 2);
}
//#endregion

//#region - Export Functions
module.exports = Day0Extraction;
//#endregion