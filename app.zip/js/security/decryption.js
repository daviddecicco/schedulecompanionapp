// Requirements
const { app } = require('@azure/functions');
const crypto = require('crypto');

// App Setup
app.setup({
    enableHttpStream: true,
});

// Decrypt
function Decrypt(key, encryption) {
    // Convert the key from ASCII to Buffer
    const decodedKey = Buffer.from(key, 'ascii');

    // Create a decipher object
    const decipher = crypto.createDecipheriv('aes-128-ecb', decodedKey, null);
    decipher.setAutoPadding(true); // Disable automatic padding

    // Decrypt the data
    let decrypted = decipher.update(encryption, 'base64', 'utf-8'); // Assuming the encrypted string is in base64
    decrypted += decipher.final('utf-8');

    // Return the decrypted string
    return decrypted.trim();
}

// Export Decrypt Function
module.exports = Decrypt;