// Requirements
const { app } = require('@azure/functions');

// App Setup
app.setup({
    enableHttpStream: true,
});

// Day 0 Data
class Day0Data {
    constructor(individualViewRecorded = false,
                groupViewRecorded = false,
                groupViewRecordedForLFG = false,
                calendarDate = '',
                guid = '',
                date = '',
                process = 'Unassigned', 
                batch = 'Unassigned', 
                po = 'Unassigned', 
                time = '', 
                country = 'Unassigned', 
                supplyType = 'Unassigned',
                workstation = 'Unassigned', 
                pod = 'Unassigned', 
                operator = 'Unassigned', 
                verifier = 'Unassigned', 
                shift = 'Unassigned', 
                incubation = 'Unassigned', 
                lfgOperator = 'N/A', 
                lfgVerifier = 'N/A', 
                slotState = 'Unassigned') {

        this.individualViewRecorded = individualViewRecorded;
        this.groupViewRecorded = groupViewRecorded;
        this.groupViewRecordedForLFG = groupViewRecordedForLFG;
        this.calendarDate = calendarDate;
        this.guid = guid;
        this.date = date;
        this.process = process;
        this.batch = batch;
        this.po = po;
        this.time = time;
        this.country = country;
        this.supplyType = supplyType;
        this.workstation = workstation;
        this.pod = pod;
        this.operator = operator;
        this.verifier = verifier;
        this.shift = shift;
        this.incubation = incubation;
        this.lfgOperator = lfgOperator;
        this.lfgVerifier = lfgVerifier;
        this.slotState = slotState;
    }
}

// Export Classes
module.exports = Day0Data;