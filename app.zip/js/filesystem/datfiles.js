//#region - Requirements
const { app } = require('@azure/functions');
const fs = require('fs');
const path = require('path');
//#endregion

//#region - App Setup
app.setup({
    enableHttpStream: true,
});
//#endregion

//#region - Read Dat File
function ReadDatFile(filePath) {
    return new Promise((resolve, reject) => {
        fs.readFile(path.join(__dirname, '../../', filePath), 'utf8', (err, data) => {
            if (err) {
                console.error('Error reading file:', err);
                global.day0session += `\n<i><u>• Error reading file at ${path.join(__dirname, '../../', filePath)}: ${err}</u></i>\n`;
                return reject(err);
            }

            try {
                // Assuming the .dat file content is JSON
                global.day0session += `\n• ReadDatFile - ${path.join(__dirname, '../../', filePath)}, 'utf8'\n`;
                const jsonData = JSON.parse(data);
                global.day0session += `• Json.parse\n${JSON.stringify(jsonData, null, 2)}, 'utf8'\n`;
                resolve(jsonData); // Return the parsed JSON data
            } catch (parseError) {
                console.error('Error parsing JSON:', parseError);
                global.day0session += `\n<i><u>• Error parsing JSON: ${parseError}</u></i>\n`;
                reject(parseError);
            }
        });
    });
}
//#endregion

//#region - Export
module.exports = ReadDatFile;
//#endregion