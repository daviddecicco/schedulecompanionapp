//#region - Requirements
const { app } = require('@azure/functions');
const fs = require('fs');
const path = require('path');
//#endregion

//#region - App Setup
app.setup({
    enableHttpStream: true,
});
//#endregion

//#region - WriteTxtFile
function WriteTxtFile(filePath, data) {
    fs.writeFile(path.join(__dirname, '../../', filePath), data, (err) => {
        if (err) {
            console.error('Error Writing to File: ', err);
        } else {
            console.log('File has been written successfully');
        }
    })    
}
//#endregion

//#region - Export
module.exports = WriteTxtFile;
//#endregion