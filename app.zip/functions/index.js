//#region - Requirements
const { app } = require('@azure/functions');
const { chromium } = require('playwright')
const Decrypt = require('../js//security/decryption');
const ReadDatFile = require('../js/filesystem/datfiles');
const WriteTxtFile = require('../js/filesystem/txtfiles');
const Day0Extraction = require('../js/extraction/day0extraction');
const SubmitHTTPRequest = require('../js/helpers/httprequest');
const {SendTextNotification, SendEmailNotification} = require('../js/errorhandling/notifications');
const GetRuntime = require('../js/helpers/various');
//#endregion

//#region - App Setup
app.setup({
    enableHttpStream: true,
});
//#endregion

//#region - Global Variables
global.startTime = performance.now();
global.day0session = `<a href="#readDatFiles">Read Dat Files</a>\n`;
global.day0session += `<a href="#browserLaunch">Browser Launch</a>\n`;
global.day0session += `<a href="#day0Extraction">Day 0 Extraction</a>\n`;
global.day0session += `<a href="#groupedViewExtraction1">Grouped View Extraction (1 of 2)</a>\n`;
global.day0session += `<a href="#individualViewExtraction1">Individual View Extraction (1 of 2)</a>\n`;
global.day0session += `<a href="#groupedViewExtraction2">Grouped View Extraction (2 of 2)</a>\n`;
global.day0session += `<a href="#individualViewExtraction2">Individual View Extraction (2 of 2)</a>\n`;
global.day0session += `<a href="#refinedData">Refine Data</a>\n`;
global.day0session += `<a href="#jsonConversion">Json Conversion</a>\n`;
global.day0session += `<a href="#submitHttpRequest">Submit HTTP Request</a>\n\n`;
//#endregion

//#region - Variables
let page;
let paths, config, processes;
const username = '#UserName';
const password = '#Password';
const login = '.login__login-button';
//#endregion

//#region - Open Browser
async function OpenBrowser() {
    try {
        // Variables
        console.log('...Reading Dat Files');
        day0session += `\n<a name="readDatFiles" id="readDatFiles"><b><u>Read Dat Files</b></u></a>\n`;
        paths = await ReadDatFile("dat/paths.dat");
        config = await ReadDatFile(paths.config);
        processes = await ReadDatFile(paths.processes);

        // Variables
        console.log('...Launching Browser');
        day0session += `\n<a name="browserLaunch" id="browserLaunch"><b><u>Browser Launch</b></u></a>\n`;
        const browser = await chromium.launch({ headless: config.headless });
        day0session += `• chromium.launch\n`;
        page = await browser.newPage( );
        day0session += `• browser.newPage\n`;

        // Navigate to the specified URL
        console.log('...Navigating to url');
        await page.goto(config.url, { waitUntil: 'domcontentloaded' });
        day0session += `• page.goto - ${config.url}\n`;

        // Login
        console.log('...Logging in');
        await page.fill(username, Decrypt(config.key, config.username));
        day0session += `• page.fill - ${username}, ${config.username}\n`;
        await page.fill(password, Decrypt(config.key, config.password));
        day0session += `• page.fill - ${password}, ${config.password}\n`;
        await page.click(login);
        day0session += `• page.click - ${login}\n`;

        // Process Specific Extraction
        console.log('...Starting Day 0 Data Extraction');
        day0session += `\n<a name="day0Extraction" id="day0Extraction"><b><u>Day 0 Extraction</b></u></a>\n`;
        let jsonDay0Data = await Day0Extraction(page, config, processes);

        // Close Browser
        console.log('...Closing Browser');
        await page.close();
        day0session += `• page.close\n`;

        // Submit HTTP Request
        console.log('...Submitting HTTP Request');
        day0session += `\n<a name="submitHttpRequest" id="submitHttpRequest"><b><u>Submit HTTP Request</b></u></a>\n`;
        await SubmitHTTPRequest(paths.day0scheduleflow, 'POST', jsonDay0Data);

        // Write Session Log
        console.log('...Writing Session File');
        WriteTxtFile(paths.day0session, `Successful\n${new Date()}\nRuntime: ${GetRuntime()}\n\n${day0session}`);
    }
    catch(error) {
        // Console Log Error
        console.error(`...Cancelling due to Error`, error);

        // Close Page
        page.isClosed() || await page.close();

        // Send Notifications
        SendTextNotification(paths, config, 'Data Extraction Error', `${new Date}-${error}`);
        SendEmailNotification(paths, config, 'Data Extraction Error', `${error}\n${new Date()}\nRuntime: ${GetRuntime()}\n\n${day0session}`)

        // Write Session Log
        WriteTxtFile(paths.day0session, `${error}\n${new Date()}\nRuntime: ${GetRuntime()}\n\n${day0session}`);
    }
}
//#endregion

//#region - Exported
module.exports = OpenBrowser;
//#endregion