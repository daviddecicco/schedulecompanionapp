// Require
const { app } = require('@azure/functions');
const OpenBrowser = require('../js/index');

process.on("uncaughtException", async(reason) => {
    console.error('Uncaught Exception: ', reason);
});

// HTTP Request
app.http('Main', {
    methods: ['GET', 'POST'],
    authLevel: 'anonymous',
    handler: async (request, context) => {
        try {
            const result = await OpenBrowser(); // Call the OpenBrowser function
            context.res = {
                status: 200,
                body: result
            };
        } catch (error) {
            context.res = {
                status: 500,
                body: `Error occurred: ${error.message}`
            };
        }

        context.log(`Testing Context Log"`);

        return { body: `testing Document Log!` };
    }
});